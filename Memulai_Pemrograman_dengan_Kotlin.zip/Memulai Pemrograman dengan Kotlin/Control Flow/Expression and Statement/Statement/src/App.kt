// main function
fun main() {

    val value1 = 10
    val value2 = 10

    var hasil = sum(value1, value2)
    println(hasil)
}

fun sum(value1: Int, value2: Int) = value1 + value2