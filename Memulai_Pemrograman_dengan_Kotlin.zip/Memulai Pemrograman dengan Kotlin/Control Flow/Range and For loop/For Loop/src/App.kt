// main function
fun main() {
    val ranges = 1..10

    for (i in ranges){
        println("value is $i!")
    }
}