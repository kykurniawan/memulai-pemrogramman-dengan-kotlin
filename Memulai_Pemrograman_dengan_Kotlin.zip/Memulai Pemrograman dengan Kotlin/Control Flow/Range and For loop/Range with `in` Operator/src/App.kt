// main function
fun main() {
    val tenToOne = 10.downTo(1)
    if (11 in tenToOne) {
        println("Value 7 available")
    }
    else {
        println("I dont know")
    }
}