// main function
fun main() {
    val ranges = 1.rangeTo(10) step 5

    for (i in ranges ){
        println("value is $i!")
    }
}